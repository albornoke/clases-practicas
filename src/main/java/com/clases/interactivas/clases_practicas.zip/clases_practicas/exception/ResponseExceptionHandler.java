package com.clases.interactivas.clases_practicas.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.clases.interactivas.clases_practicas.dto.response.*;
import com.clases.interactivas.clases_practicas.model.*;

import jakarta.servlet.http.HttpServletRequest;

@ControllerAdvice
@Slf4j
public class ResponseExceptionHandler extends ResponseEntityExceptionHandler{
    @Autowired
    HttpServletRequest httpServletRequest;

    @ExceptionHandler(Exception204.class)
    public ResponseEntity<ApiResponse204> handlerError204(HttpServletRequest request, Exception204 ex){
        log.warn(ex.getMessage(), ex);
        ApiResponse204 response = new ApiResponse204();
        response.setCode(HttpStatus.NO_CONTENT.value());
        response.setMessage("No se encontro contenido");
        return new ResponseEntity<>(response, HttpStatus.NO_CONTENT);
    }

    @ExceptionHandler(Exception400.class)
    public ResponseEntity<ApiResponse400> handlerError400(HttpServletRequest request, Exception400 ex) {
        log.warn(ex.getMessage(), ex);
        ApiResponse400 response = new ApiResponse400();
        response.setCode(HttpStatus.BAD_REQUEST.value());
        response.setMessage("Los datos ingresados son invalidos"); 
        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception409.class)
    public ResponseEntity<ApiResponse409> handlerError409(HttpServletRequest request, Exception409 ex) {
        log.warn(ex.getMessage(), ex);
        ApiResponse409 response = new ApiResponse409();
        response.setCode(HttpStatus.CONFLICT.value());
        response.setMessage("El recurso esta duplicado."); // O un mensaje genérico
        return new ResponseEntity<>(response, HttpStatus.CONFLICT);
    }

    @ExceptionHandler(Exception424.class)
    public ResponseEntity<ApiResponse424> handlerError424(HttpServletRequest request, Exception424 ex) {
        log.warn(ex.getMessage(), ex);
        ApiResponse424 response = new ApiResponse424();
        response.setCode(HttpStatus.FAILED_DEPENDENCY.value());
        response.setMessage("Ocurrio un error inesperado, por favor comunicarse con el area de soporte."); // O un mensaje genérico
        return new ResponseEntity<>(response, HttpStatus.FAILED_DEPENDENCY);
    }
}
