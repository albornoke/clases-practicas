package com.clases.interactivas.clases_practicas.exception;

public class Exception424 extends RuntimeException{
    public Exception424(String message) {
        super(message);
    }
}
