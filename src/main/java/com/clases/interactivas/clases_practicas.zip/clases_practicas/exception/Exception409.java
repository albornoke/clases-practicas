package com.clases.interactivas.clases_practicas.exception;

public class Exception409 extends RuntimeException{
    public Exception409(String message) {
        super(message);
    }
}
