package com.clases.interactivas.clases_practicas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClasesPracticasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClasesPracticasApplication.class, args);
	}

}
