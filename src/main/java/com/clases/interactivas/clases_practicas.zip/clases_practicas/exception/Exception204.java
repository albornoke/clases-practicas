package com.clases.interactivas.clases_practicas.exception;

public class Exception204 extends RuntimeException{
    public Exception204(String message) {
        super(message);
    }
}
