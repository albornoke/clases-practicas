package com.clases.interactivas.clases_practicas.exception;

public class Exception400 extends RuntimeException{
    public Exception400(String message) {
        super(message);
    }
}
